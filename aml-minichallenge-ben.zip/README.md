# fhnw-aml-Angewandtes-Machine-Learning
Mini-Challenge: Kreditkarten Affinitätsmodell  
Die Mini-Challenge spezifiziert den Inhalt für die benotete schriftliche Abgabe und deckt LE1 bis LE5 ab.

Grundlagen  
Intro to Product Affinity Modeling

Aufgabenstellung  
Kreditkarten Affinitätsmodell Aufgabenstellung (FS23)

Daten   
xselling_banking_data-1  
https://sorry.vse.cz/~berka/challenge/PAST/index.html (Beschreibung der Daten)